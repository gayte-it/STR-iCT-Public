==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 

==============================================================================
  Dokumentet levereras i befintligt skick utan några som helst garantier.  
  IBM lämnar inga garantier, vare sig uttryckliga eller underförstådda,
  inklusive, men inte begränsat till, underförstådda garantier om
  lämplighet för ett visst syfte eller allmän beskaffenhet vad avser
  informationen i detta dokument. Dokumentet ger ingen licens till
  patent eller upphovsrätt. 

===============================================================================

Dokumentet uppdaterades senast 04 november 2019

------------------------------------------------------------------- 

INNEHÅLL 

-------------------------------------------------------------------  

1.0 Introduktion
2.0 Informationsresursplats
3.0 Installation
  3.1 Windows-operativsystem som hanteras
  3.2 Om installation
  3.3 Uppgradering från IBM i Access for Windows
  3.4 Installera
  3.5 Åtgärder som krävs efter installation av skrivardrivrutin
  3.6 Om 64-bitarsinstallation
  3.7 Installationsloggar
4.0 Krav för IBM.Data.DB2.iSeries .NET Provider
5.0 Microsoft XML Parser och Microsoft XML Core Services
6.0 Information för avancerad installation
  6.1 Information om licensierade produkter
  6.2 Språkfiler i installationsavbildningen
  6.3 Installationsfunktioner
  6.4 Kommandoradsalternativ
  6.5 Allmänna egenskaper
  6.6 Bränna administrativa avbildningar till CD och DVD
7.0 Policyinformation
8.0 Kommandon som inte ingår
  


-------------------------------------------------------------------

1.0 Introduktion
----------------
  Det här paketet är en del av 5733XJ1 IBM i Access Client Solutions-produkten.

  Du kan använda IBM i Access Client Solutions för att ansluta till alla IBM i-
  versioner som hanteras.

  Paketet innehåller funktioner som endast är tillgängliga i Windows-system.
  Det baseras på 7.1 IBM i Access for Windows men innehåller inte alla funktioner.

  Följande funktioner från IBM ingår i Access for Windows:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer och Certificate Management
    Programmer's Toolkit for Headers, Libraries and Documentation
    AFP Printer Driver
    Erforderliga program inklusive:
      API:er
      Active X
      Säkerhet
      Tillgänglighet
      Anslutningar
      NLS-aktivering
      Konverteringstabeller
      Egenskaper
      Principer
      Nätverksutskrifter
      Deluppsättning av kommandon (i avsnitt 8.0 visas en lista över vad som ingår.)
      Användarhandbok
      Användning av tillämpningsadministration för styrning av åtkomst
      till funktioner

  Följande funktioner från IBM i Access for Windows ingår inte i paketet. 
  
  Det plattformsoberoende IBM i Access Client Solution-paketet innehåller
  en ersättning för följande funktioner:
    5250-skärm- och skrivaremulering
    Dataöverföring
    Excel-tillägg för dataöverföring
    Operations Console
  
  Följande funktioner från IBM i Access for Windows ingår inte i paketet. 
  
  IBM Navigator for i innehåller en ersättning för följande funktioner:
    System i Navigator
    AFP Workbench Viewer

  Inkommande fjärrkommando ingår inte.  Använd Microsofts
  Anslutning till fjärrskrivbord i stället.

  Toolbox for Java ingår inte heller.  Gå till följande webbplats för
  hämtning av information:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Andra funktioner i IBM i Access for Windows som inte ingår i paketet:
    SCS-skrivardrivrutin
    Insticksprogram Java Programmer's Tools for System i Navigator
    Kataloguppdatering
    Lotus 123-filformatsfunktioner
    Servicenivåkontroll

  Eftersom innehållet i det här paketet även levereras med
  7.1 IBM i Access for Windows återspeglar dokumentationen
  ofta 7.1 IBM i Access for Windows i användarhandboken,
  Programmer's Toolkit, hjälptext och meddelanden men den gäller
  även IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Informationsresursplats

-------------------------------------------------------------------

- Information om ändringar av IBM i Access Client Solutions inklusive
    hanterade operativsystem, uppdateringar, begränsningar, kända problem,
    nyheter och annat publiceras på IBM i Access-produktwebbplatsen:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Användarhandboken som finns i paketet innehåller information om
    hur produkten används, tips och metoder, meddelanden och felsökning.

  - Tekniska referenser till OLE DB och .NET Data Provider installeras
    tillsammans med biblioteks- och dokumentationsfunktionen.  
    Referenserna återfinns i Programmer's Toolkit-mappen.

  - I IBM i Information Center finns teknisk information som
    riktar sig till erfarna IBM i-användare:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - När det här publicerades innehöll IBM i Information Center
    inte någon information om IBM i Access Client Solutions.
    Mycket av informationen under IBM i Access for Windows
    gäller dock det här paketet med IBM i Access Client Solutions
    inklusive information om installation, administration och
    programmering:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks innehåller artiklar, självstudiekurser
    och teknisk information för IBM i-användare:

    https://www.ibm.com/developerworks/ibmi

  - På IBM i-webbplatsen finns de senaste IBM i-nyheterna samt
    produktinformation, ett referensbibliotek, information om
    utbildning och annat:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installationsinformation
-------------------------------------------------------------------



3.1 Windows-operativsystem som hanteras
---------------------------------------

  Paketet kan installeras i följande Microsoft Windows-
  operativsystem:

     Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2

   - Windows Server 2008 and Windows Server 2008 R2
         Standard Enterprise (32-bit och 64bit)
   - Windows 7
         Professional, Enterprise, och Ultimate (32-bit and 64-bit)

   Följande begränsningar gäller:
 
          a) Home-versioner hanteras inte.
          b) Du måste använda de Windows servicepacknivåer som
        Microsoft tillhandahåller.
          c) Supporten upphör det datum Microsoft inte längre
        ger support för operativsystemen.
          d) Installation kan inte göras på Itanium-maskinvara.
          e) Följ Microsofts rekommendationer för maskinvara och minnen. 
        Räkna med ytterligare 256 MB minne för IBM i Access Client
        Solution-funktioner.
          f) Produkten kan inte installeras vid uppgradering till ett
        annat Windows-operativsystem.  Gör så här:
          1.  Spara konfigurationsdata.
          2.  Avinstallera produkten.
               3.  Uppgradera Windows-operativsystemet.
               4.  Installera produkten.
               5.  Återskapa konfigurationsdata.


3.2 Om installation
-------------------

  - Det krävs administratörsbehörighet för att köra installationen.
  
  - Installationen kan bara göras per dator.  Det går inte att
    installera per användare.

  - Windows Installer 4.5 krävs.  Den Microsoft-programkomponenten
    installeras automatiskt när produkten installeras om den inte
    redan har installerats.  Du kan installera den innan du
    installerar produkten genom att hämta komponenten från Microsofts
    webbplats:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Uppgradera från IBM i Access for Windows
--------------------------------------------

  -  Uppgradering från IBM i Access for Windows stöds inte.  Du måste ta
     bort IBM i Access for Windows innan du installerar det här paketet.  

  -  I avsnitt 1.0 listas de funktioner som inte ingår.  Om du vill
     fortsätta att använda funktioner i IBM i Access for Windows som
     inte ingår i det här paketet ska du inte installera paketet
     utan fortsätta att använda det senaste servicepaketet
     7.1 IBM i Access for Windows.

  -  När IBM i Access for Windows avinstalleras tas befintlig system-
     konfiguration bort.  För att bevara den befintliga system-
     konfigurationen måste du spara den innan du avinstallerar IBM
     i Access for Windows och sedan återställa konfigurationen efter att IBM
     i Access Client Solutions Windows Application-paketet har installerats.

     Spara och återställa konfigurationen:
     1.  Använd kommandot CWBBACK för att säkerhetskopiera IBM i Access for Windows-
         konfigurationen.
             cwbback <filnamn.rs> /u
         Exempel:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Exemplet förutsätter att mappen C:\Users\IBM_ADMIN\Backup redan finns.

         Kommandot skapar två filer i den mappen:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	        Kontrollera att filerna har skapats innan du fortsätter.

         Anm.
         Om filerna inte skapades har konfigurationen inte sparats.
         Försök köra kommandot som administratör.
         Ett sätt att göra det
         är att starta en kommandoprompt enligt följande:
             Start -> Alla program -> Tillbehör -> Kommandotolken
         I stället för att vänsterklicka på kommandoprompten högerklickar
         du och väljer alternativet Kör som administratör.
         Kör kommandot
         cwbback med den här kommandoprompten.
                  Kontrollera att filerna skapades innan du fortsätter.

     2.  Avinstallera IBM i Access for Windows.
          3.  Starta om.
          4.  Installera IBM i Access Client Solutions Windows Application-paketet.
          5.  Starta om.
          6.  Kör kommandot CWBREST för att återställa konfigurationen som sparades
         med kommandot CWBBACK.
                          cwbrest <filenamn.rs> /c
         Exempel:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Om du följde anvisningarna i avsnittet Anm. i steg 1 måste du
         köra kommandot cwbrest som administratör från kommandoraden.

  -  Det finns ett par sätt att verifiera Windows-konfigurationen före och
     efter ovanstående steg:
     1. Kontrollera Windows-registret.  Systemkonfigurationerna lagras i:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Om du vill se innehållet på den platsen i Windows-registret kör du följande kommando:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Om miljön har ett annat namn än standardnamnet "My Connections", skriver du
        det namnet i sökvägen.

     2. Om du använder en plattformsoberoende version av IBM i Access Client Solutions
        på samma dator kan du välja följande från huvudgränssnittet:
            Arkiv -> Kopiera anslutningar
        På den högra sidan visas "IBM i Access (Windows)".  Det är den
        konfiguration som används både för IBM i Access for Windows och för
        IBM i Access Client Solutions Windows Application-paketet.


3.4 Installera
--------------

  - Kör setup.exe i installationsavbildningen så startar installationen.  (Filen
    cwblaunch.exe används inte för den här produkten.)
   
      
      Anm. Direkt anrop av MSI-filer (Microsoft Installer)
           rekommenderas inte eftersom setup.exe använder
           setup.ini för en lista över kommandoradsalternativ
           som ska användas och för att uppdatera Windows
           Installer-versionen om det behövs.
    
    - Det rekommenderas att du använder standardinstallations-
      katalogen.
      Om du byter mapp:
     
           a) Välj inte rotkatalogen på en enhet.
           b) Välj en katalog som inte innehåller filer relaterade till
         den här produkten.
           c) Välj inte en nätverksenhet.  Installation på en nätverksenhet
         hanteras inte.


3.5 Åtgärder efter installation av skrivardrivrutin
---------------------------------------------------

  Om du installerar AFP-skrivardrivrutinen måste du vidta
  åtgärder innan du använder den.  Det behövs eftersom
  skrivardrivrutinen inte kan läggas till eller uppdateras
  automatiskt vid installationen vilket beror på att den
  inte signeras digitalt av Microsoft.  

  Under installationen kopieras drivrutinsfilerna till en
  underkatalog med namnet CWBAFP i installationssökvägen.
  Om du installerade produkten i standardsökvägen hittar du
  underkatalogen på följande plats:

  c:\Program Files\IBM\Client Access\CWBAFP 

  Följ Microsofts anvisningar för att lägga till eller uppdatera
  skrivardrivrutinen.
  Ange sökvägen till CWBAFP när du får en
  uppmaning att göra det. 

  Om du installerar på en dator där IBM i Access for Windows
  har uppgraderas över flera releaser kan gammal information
  visas när du konfigurerar skrivardrivrutinen.  Ta bort den föråldrade informationen från .inf-filer på följande
  sätt när du har slutfört installationen:

    a) Öppna ett kommandoradsfönster
        b) Gå till installationskatalogen. Standardinstallationskatalogen
       är c:\Program\IBM\Client Access.
        c) Skriv "cwbrminf" och tryck på Enter. 


3.6 Om 64-bitarsinstallation
----------------------------

  Installation i 64-bitars Windows-operativsystem:
  
  -  Både 32- och 64-bitarsversionen installeras för ODBC, OLE DB,
     ActiveX och SSL (Secure Sockets Layer).  

  -  IBM i Access for Windows .NET körs från både 32- och
     64-bitarstillämpningen beroende på den tillämpning som
     anropar funktionen.

  -  Endast en version av AFP-skrivardrivrutinen installeras.
     64-bitarsversionen installeras i 64-bitarssystem och
     32-bitarsversionen i 32-bitarssystem.


3.7 Installationsloggar
-----------------------

  Två loggar skapas under installationen. En av loggarna är specifik
  för XJ1 och innehåller information om produktanpassning.  
  Den loggen heter "xe1instlog.txt" och skapas i användarens
  temp-katalog.

  Den andra loggen är Microsofts MSI-logg som innehåller information
  om MSI-händelser, sekvenser och egenskaper.  Som standard har den här
  loggen namnet "xe1instlogmsi.txt" och skapas i användarens tempkatalog.   Du
  kan ändra loggen genom att redigera setup.ini i installations-
  avbildningen.    Gå till nyckelordet [Startup] och sök efter samt ändra följande
  rad: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Ta bort raden om du inte vill att loggen ska skapas.
    - Byt plats och namn på loggen genom att ändra sökvägen
      och filnamnet.
    - Om du vill ändra innehållet i loggen ändrar du /l* till
      något annat enligt kommandoradsalternativen för Microsofts
      MSDN Windows Installer på följande plats: 

      http://msdn.microsoft.com/default.aspx   

  Standardkommandoradsinformationen i setup.ini kan åsidosättas
  genom att starta setup.exe på kommandoraden och ange alternativ.



-------------------------------------------------------------------

4.0 Krav för IBM.Data.DB2.iSeries .NET Provider 

-------------------------------------------------------------------

  - IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    kräver att Microsoft .NET Framework version 2.0 eller senare
    installeras i systemet.  De flesta datorer med ett hanterat
    Microsoft-operativsystem har redan .NET Framework installerat.
   .NET Framework kan hämtas på följande
    Microsofts webbplats: 

    http://www.microsoft.com/net 

  - För att undvika fel för .NET-tillämpningar som skrevs till gräns-
    snittet för Access for Windows 5.3 eller 5.4 .NET Provider måste
    Runtime-begäran för 10.0.0.0-versionen av .NET Provider omdirigeras
    till 12.0.0.0-versionen.
    I avsnittet "Incompatible changes from 5.3 and 5.4" i IBM DB2 för i
    .NET Provider Technical Reference finns anvisningar om att använda
    filen app.config, web.config eller machine.config och information
    om att välja ett lämpligt kompileringsprogram för befintliga
    tillämpningar.

    Tillämpningen kan även kompileras om med ett nyare kompilerings-
    program för att stämma med den version 12.0.0.0 av .NET Provider
    som ingår i IBM i Access for Windows 7.1.

  - Fullständig information om och en lista över inkompatibilitet för
    ändringar finns i Headers, Libraries och Documentation i
    .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser och Microsoft XML Core Services

-------------------------------------------------------------------

  När du använder ActiveX-automatiseringsobjekt i IBM i Access for
  Windows Dataöverföring för överföring av filer till och från
  Microsoft Excel XML-format (hanteras för Excel 2003 och
  Excel XP) måste ytterligare program installeras på datorn. 
  Detta kräver att Microsoft XML Parser 3.0 eller senare, även känt som
  Microsoft XML Core Services installeras. XML Parser
  ingår i många Microsoft-produkter.  För att ta reda på om funktioner
  för XML Parser är installerade på datorn går du till Microsoft
  KB-artikel 278674.  Artikeln finns på Microsofts webbplats:

  http://support.microsoft.com/kb/278674

  Om Microsoft XML Parser 3.0 eller senare inte hittas följer du
  Microsofts webbinstruktioner för att hämta och installera XML Parser
  innan du kan använda Data Transfer XML.  I Microsoft KB-artikeln
  324460 finns information om hur du installerar XML Parser.  Artikeln
  finns på följande adress:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Information för avancerad installation

-------------------------------------------------------------------

  Du kan använda det mesta av informationen om anpassning av
  användargränssnittet, användning av kommandoradsparametrar
  och styrning av andra installations- och spridningsmetoder i
  avsnittet "Setting up the PC" i IBM i Information Center for
  IBM i Access for Windows.  Skillnader beskrivs i det här avsnittet.


6.1 Information om licensierade produkter
-----------------------------------------
  
  5733XJ1 paketeras inte som en licensierad produkt som
  ska installeras i IBM i-operativsystemet.
  Den är endast
  tillgänglig som datormedium. Du kan kopiera produkten till
  ett IBM i-system på en plats tillgängliga för användarna.
  

6.2 Språkfiler i installationsavbildningen
------------------------------------------
  
  Språkinstallationsfilerna ligger inte längre i olika MRI29xx-
  kataloger. I stället finns det separata CAB-filer för varje språk.  
  Du kan inte ta bort CAB-filerna.


6.3 Installationsfunktioner
---------------------------

  Vissa installationsfunktioner i IBM i Access for Windows
  är beroende av att andra installationsfunktioner installeras.
  Den begränsningen gäller inte det här paketet.

  Följande installationsfunktioner krävs:
    req (Required Programs)
    langacs, amri2924 (English)

  Alla andra installationsfunktioner installeras som standard
  men du kan ändra den inställningen.

  Språk är nu installationsfunktioner i likhet med program som krävs,
  ODBC, osv. Eftersom språk är installationsfunktioner kan du styra vilka
  språk som installeras på samma sätt som andra installationsfunktioner.
  Installationsfunktionsnamnen för språken är amri29xx.  


6.4 Kommandoradsalternativ
--------------------------

  Standardkommandoradsalternativen anges i filen setup.ini i
  installationsavbildningen.  Alternativen ignoreras om du anropar
  setup.exe från kommandoraden med något alternativ.  

  Om du använder transformering på kommandoraden ignoreras
  kommandoradsvärdena i setup.ini eftersom transform är ett alternativ.
  Du kan behöva inkludera andra alternativ på kommandoraden, t.ex.
  för loggningsinformation.

  Mer information finns i avsnitt 3.7 Installationsloggar.


6.5 Allmänna egenskaper
-----------------------

  Vissa av de allmänna egenskaperna i IBM i Access for Windows
  gäller även det här paketet.  Det finns några ändringar jämfört med
  användningen i IBM i Access for Windows enligt följande:

  CWBINSTALLTYPE   Används endast vid förstagångsinstallation.  De enda
                   värdena är Typical och Custom.  Standard är Typical.
                                      Exempel:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Primärt standardspråk är datorns språkmiljö.  Med den
                   här egenskapen kan du ange ett annat primärt språk. Värdet
                   som ska användas är MRI29xx. 
                   
                   Exempel:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Den här egenskapen används på samma sätt som för
                   IBM i Access for Windows.  Du kan använda den för att
                   uppgradera SSL-filerna vid en uppgradering.  Om SSL-
                   konfigurationsfilerna hittas på måldatorn uppdateras
                   filerna med de senaste certifikaten.  Värdena är Yes och
                   No. Standardvärdet är Yes.
                                      Exempel:  setup /vCWBUPGSSLFILES=NO

  De vanliga Windows Installer-egenskaperna i IBM i Access for Windows
  Information Center gäller fortfarande: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Det finns en begränsning för användning av Windows Installer-egenskapen
  REBOOT med IBM i Access for Windows.  Den begränsningen gäller inte det
  här paketet.
  

6.6 Bränna administrativa avbildningar till CD och DVD
------------------------------------------------------

  På grund av problem med hur vissa CD- och DVD-bränningsprogram
  hanterar långa filnamn rekommenderas inte att du bränner en
  administrativ avbildning till CD eller DVD. Om du får problem
  vid installation från en CD eller DVD som innehåller en administrativ
  avbildning av IBM i Access for Windows, kopierar du avbildningen
  till en katalog på den lokala hårddisken och kör setup.exe från
  den lokala kopian.

-------------------------------------------------------------------
7.0 Policyinformation
-------------------------------------------------------------------

  Samma policyfil används för både det här paketet och för IBM i
  Access for Windows. Det betyder att några policytyper inte är
  tillämpbara för det här paketet eftersom inte alla IBM i Access
  for Windows-funktioner ingår i paketet.

-------------------------------------------------------------------

8.0 Kommandon
-------------------------------------------------------------------

  IBM i Access for Windows-kommandon som inte finns i detta paket:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[SLUT PÅ DOKUMENTET]
