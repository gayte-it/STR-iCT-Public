==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Pacchetto applicazione Windows 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Tutti i diritti riservati. 

==============================================================================
  IBM fornisce la presente pubblicazione 'nello stato in cui si trova'.  Senza garanzie di alcun tipo, né espresse né implicite, ivi incluse,
    a titolo esemplificativo, garanzie implicite di non violazione,
    commerciabilità o idoneità ad uno scopo particolare. Fornendo questo documento, l'IBM non concede licenze per brevetti
    o copyright. 

===============================================================================

Ultimo aggiornamento del documento:  4 novembre 2019

------------------------------------------------------------------- 

INDICE 

-------------------------------------------------------------------  

1.0 Introduzione
2.0 Ubicazione delle fonti di informazioni
3.0 Installazione
  3.1 Sistemi operativi Windows supportati
  3.2 Considerazioni sull'installazione
  3.3 Aggiornamento da IBM i Access per Windows
  3.4 Esecuzione dell'installazione
  3.5 Azione richiesta dopo l'installazione del Programma di controllo stampante
  3.6 Considerazioni sull'installazione su hardware a 64 bit
  3.7 File di registrazione dell'installazione
4.0 Requisiti .NET Provider IBM.Data.DB2.iSeries
5.0 Microsoft XML Parser o Microsoft XML Core Services
6.0 Informazioni sull'installazione avanzata
  6.1 Informazioni sul prodotto su licenza
  6.2 File della lingua nell'immagine di installazione
  6.3 Funzioni di installazione
  6.4 Opzioni della riga comandi
  6.5 Proprietà pubbliche
  6.6 Masterizzazione delle immagini amministrative su CD o DVD
7.0 Informazioni sulle normative
8.0 Comandi non inclusi
  


-------------------------------------------------------------------

1.0 Introduzione
-------------------------------------------------------------------
  Questo pacchetto fa parte del prodotto 5733XJ1 IBM i Access Client Solutions.

  È possibile utilizzare IBM i Access Client Solutions per connettersi a qualsiasi release di IBM i
  supportato.

  Questo pacchetto contiene funzioni disponibili solo su sistemi operativi Windows.  Si basa sul prodotto IBM i Access per Windows versione 7.1, ma non ne contiene tutte le funzioni.

  Le funzioni incluse in questo pacchetto, provenienti da IBM i Access per Windows sono:
    .NET Data Provider
    ODBC
    OLE DB
    SSL (Secure Socket Layer) e Gestione certificati
    Programmer's Toolkit per Intestazioni, Librerie e Documentazione
    Programma di controllo stampante AFP
    Programmi richiesti, incluso:
      API
      Active X
      Sicurezza
      Funzionalità
      Connessioni
      Abilitazione NLS
      Tabelle di conversione
      Proprietà
      Normative
      Stampa di rete
      Sottoinsieme di comandi (fare riferimento alla sezione 8.0 per un elenco di elementi non inclusi)
      Guida per l'utente
      Utilizzo di Gestione applicazione per controllare l'accesso a funzioni nel pacchetto

  Le seguenti funzioni provenienti da IBM i Access per Windows non sono incluse in questo pacchetto. 
  Il pacchetto IBM i Access Client Solution indipendente dalla piattaforma, include una sostituzione
  delle seguenti funzioni:
    Emulazione video e stampante 5250
    Trasferimento dati
    Componente aggiuntivo Excel Trasferimento dati
    Operations Console
  
  Le seguenti funzioni provenienti da IBM i Access per Windows non sono incluse in questo pacchetto. 
  IBM Navigator per i include una sostituzione per le seguenti funzioni:
    System i Navigator
    AFP Workbench Viewer

  Comando remoto in entrata, non è incluso.  In sostituzione utilizzare Servizi Desktop remoto di Microsoft.

  Anche Toolbox per Java non è incluso.  Utilizzare i seguenti siti web per scaricare
  informazioni:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Altre funzioni provenienti da IBM i Access per Windows non incluse in questo pacchetto sono:
    Programma di controllo stampante SCS
    Moduli aggiuntivi Java Programmer's Tools per System i Navigator
    Aggiornamento indirizzario
    Supporto formato file Lotus 123
    Controllo livello di servizio

  Poiché il contenuto di questo pacchetto viene inviato anche con IBM i Access per Windows 7.1,
  la documentazione fa spesso riferimento a tale prodotto nella guida per l'utente, nel Programmer's
  Toolkit, nei messaggi e nel testo della guida, ma le informazioni sono valide anche per
  IBM i Access Client Solutions - Pacchetto applicazione Windows.


-------------------------------------------------------------------

2.0 Ubicazione delle fonti di informazioni

-------------------------------------------------------------------

  - Le modifiche a IBM i Access Client Solutions, incluso sistemi operativi supportati, aggiornamenti,
    limitazioni, problemi noti significativi, nuove informazioni ed altro, verranno
    pubblicate sul sito web del prodotto IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - La guida per l'utente installata con questo pacchetto contiene informazioni sull'utilizzo
    del prodotto, alcuni suggerimenti e tecniche, messaggi e informazioni sulla risoluzione dei problemi.

  - Quando è installata la funzione Intestazioni, Librerie e Documentazione, vengono installati
    i riferimenti tecnici al provider OLE DB e a .NET Data Provider.  È possibile
    reperire i riferimenti tecnici nella cartella Programmer's Toolkit.

  - L'Information Center di IBM i fornisce una raccolta di argomenti progettati per i professionisti di IBM i che necessitano
dell'accesso alle informazioni tecniche:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Al momento della diffusione del presente documento,
l'Information Center di IBM i non contiene argomenti relativi a IBM i Access Client Solutions.  Tuttavia, gran parte delle informazioni nella sezione IBM i Access
    per Windows è valida anche per questo pacchetto di IBM i Access Client Solutions, incluso
    gli argomenti relativi a installazione, gestione e programmazione:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks contiene articoli, supporti didattici e risorse tecniche per gli utenti IBM i:

    https://www.ibm.com/developerworks/ibmi

  - Il sito web di IBM i documenta le ultime novità di IBM i, fornisce le informazioni sui prodotti, una libreria di riferimento, le roadmap di formazione e molto altro:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informazioni sull'installazione
-------------------------------------------------------------------



3.1 Sistemi operativi Windows supportati
---------------------------------------

  È possibile installare questo pacchetto sui seguenti sistemi operativi Microsoft Windows:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 e Windows Server 2008 R2
         Standard Enterprise (32 bit e 64 bit)
   - Windows 7
         Professional, Enterprise e Ultimate (32 bit e 64 bit)

   Si applicano le seguenti limitazioni:
 
     a) Le Home Edition non sono supportate.
     b) È necessario utilizzare livelli di service pack Windows supportati da Microsoft.
     c) Il supporto viene interrotto alla data in cui finisce il supporto Microsoft.
     d) L'installazione non è supportata su hardware Itanium.
     e) Utilizzare hardware Microsoft Windows e seguire le indicazioni sui requisiti di memoria. Aggiungere ulteriori
        256 MB di memoria per le funzioni di IBM i Access Client Solution.
     f) Non è possibile installare il prodotto durante l'aggiornamento a un altro sistema operativo
        Windows.  Seguire queste operazioni:
          1.  Salvare i dati di configurazione.
          2.  Disinstallare il prodotto.
          3.  Aggiornare il sistema operativo Windows.
          4.  Installare il prodotto.
          5.  Ripristinare i dati di configurazione.


3.2 Considerazioni sull'installazione
--------------------------------------------------

  - I privilegi e le autorizzazione di amministrazione sono richiesti per eseguire l'installazione.
  
  - Sono supportate solo installazioni per macchina.  Non sono supportate installazioni
    per utente.

  - È richiesto Windows Installer 4.5.  Questo componente di software Microsoft
viene installato con l'installazione, se non è già presente sul sistema.  È anche
possibile applicarlo prima dell'installazione, scaricandolo dal sito web di Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Aggiornamento da IBM i Access per Windows
-------------------------------------------

  -  L'aggiornamento da IBM i Access per Windows non è supportato.  È necessario
     rimuovere IBM i Access per Windows prima di installare questo pacchetto.  

  -  Fare riferimento alla sezione 1.0
     per conoscere l'elenco delle funzioni non incluse.  Se si desidera continuare ad utilizzare le funzioni in IBM i Access per Windows non incluse in questo pacchetto, non installare il pacchetto e continuare a utilizzare l'ultimo service pack di 7.1 IBM i Access per Windows.

  -  Quando IBM i Access for Windows è disinstallato, verrà eliminata la
     configurazione di sistema esistente.  Per preservare la configurazione di
     sistema esistente, occorre salvare la configurazione prima di disinstallare
     IBM i Access for Windows e successivamente ripristinare la configurazione dopo l'installazione
     del pacchetto applicazione Windows di IBM i Access Client Solutions.

     Di seguito i passaggi dettagliati per eseguire il salvataggio e il ripristino della configurazione:  Utilizzare il comando CWBBACK per eseguire il backup della configurazione di IBM i Access per Windows.
             cwbback <nomefile.rs> /u
         Ad esempio:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Questo esempio presume che la cartella C:\Users\IBM_ADMIN\Backup sia già esistente.

         Il comando precedente crea due file in tale cartella:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Assicurarsi che i due file siano stati creati, prmima di procedere con il passaggio successivo.

         NOTA:
         se i due file non vengono creati, non si dispone di una configurazione
salvata.  Eseguire il comando come un amministratore di livello elevato.
         Un modo per eseguire questa operazione consiste nell'aprire una richiesta comandi come segue:
Start->Tutti i programmi->Accessori->Prompt dei comandi, ma invece di utilizzare
il tasto sinistro su Prompt dei comandi, utilizzare il tasto destro e selezionare l'opzione
"Esegui come amministratore".
         Eseguire il comando cwbback sopra indicato con questa richiesta comandi.
         Assicurarsi
che i file sopra indicati siano stati creati, prmima di procedere con il passaggio successivo.

     2.  Disinstallare IBM i Access per Windows.
     3.  Riavviare.
     4.  Installare IBM i Access Client Solutions - Pacchetto applicazione Windows.
     5.  Riavviare.
     6.  Utilizzare il comando CWBREST per ripristinare la configurazione salvata con il comando CWBBACK.
             cwbrest <nomefile.rs> /c
         Ad esempio:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Se è stato richiesto di seguire le istruzioni nella NOTA del passo 1, sarà anche necessario eseguire il comando cwbrest da una richiesta comandi come amministratore di livello elevato.

  -  Esistono due modi per verificare la configurazione      Windows prima e dopo i passi precedenti:
     1. Controllare il registro Windows.  Le configurazioni di sistema sono memorizzate
in: HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Per visualizzare il contenuto del registro Windows in tale ubicazione, immettere il comando:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Se il proprio ambiente ha un nome diverso da quello predefinito
        "My Connections", effettuare le sostituzioni appropriate nel percorso
        sopra indicato.

     2. Se si dispone di una versione con piattaforma indipendente di IBM i Access Client Solutions sullo stesso
        PC, dal pannello principale della GUI è possibile selezionare:
            File->Copia connessioni
        Sul lato destro viene visualizzato "IBM i Access (Windows)".  Questa
        è la configurazione utilizzata per IBM i Access per Windows e per il pacchetto applicazione Windows di IBM i Access Client Solutions.


3.4 Esecuzione dell'installazione
-----------------------

  - Eseguire setup.exe nell'immagine di installazione per avviare l'installazione.  Il comando
    cwblaunch.exe non viene inviato con questo prodotto.
   
      NOTA: il richiamo diretto di file MSI (Microsoft Installer) non è consigliato
            poiché setup.exe utilizza setup.ini per poter utilizzare un elenco di opzioni della riga comandi
            e per aggiornare la versione di Windows Installer, se necessario.
    
  - Si consiglia l'utilizzo della cartella predefinita di destinazione.  Tuttavia, se si cambia cartella:
     
     a) Non selezionare l'indirizzario root di un'unità.
     b) Non selezionare un indirizzario che contenga già file
        non correlati a questo prodotto.
     c) Non selezionare un'unità di rete.  L'installazione a un'unità di
	    rete non è supportata.


3.5 Azione richiesta dopo l'installazione del Programma di controllo stampante
---------------------------------------------------

  Se si installa un programma di controllo stampante APF, è necessario intraprendere un'azione prima
  di utilizzare tale programma.  Ciò è necessario poiché il programma di controllo stampante
  non può essere automaticamente aggiunto o aggiornato durante l'installazione in quanto non dispone
  di firma digitale di Microsoft.  

  Durante l'installazione, i file del programma di controllo stampante
  vengono copiati in un sottoindirizzario denominato CWBAFP nel percorso
  di destinazione scelto.  Presumendo di aver effettuato l'installazione nel percorso
  di destinazione predefinito, il percorso sarà:

  c:\Program Files\IBM\Client Access\CWBAFP 

  Utilizzare le indicazioni di Microsoft nel testo della guida,
  per aggiungere o aggiornare il programma di controllo stampante.
  Quando richiesto, specificare il percorso a CWBAFP. 

  Se si sta effettuando un'installazione su un PC dove il prodotto IBM i Access per Windows
  è stato aggiornato per più release, potrebbero venire visualizzate alcune vecchie informazioni
  quando si configura il programma di controllo stampante.  Per eliminare le informazioni obsolete dai file .inf, effettuare quanto segue dopo aver
  completato l'installazione:

    a) Aprire una finestra della richiesta comandi.
    b) Modificare l'indirizzario nell'indirizzario di installazione. L'indirizzario
        predefinito di installazione è c:\Program Files\IBM\Client Access.
    c) Immettere "cwbrminf" e premere Invio. 


3.6 Considerazioni sull'installazione su hardware a 64 bit
-----------------------------------------------

  Quando l'installazione avviene su un sistema operativo Windows a 64 bit supportato:
  
  -  Vengono installate entrambe le versioni, a 32 e a 64 bit, per ODBC, OLE DB,
     ActiveX e SSL (Secure Sockets Layer).  

  -  IBM i Access per Windows .NET Provider funziona sia su applicazioni
     a 32 bit che su quelle a 64 bit, a seconda dell'applicazione che richiama il provider.

  -  Viene installata una sola versione del Programma di controllo stampante AFP.  La versione a 64 bit
     viene installata su sistemi a 64 bit e quella a 32 su sistemi a 32 bit.


3.7 File di registrazione dell'installazione
---------------------

  Durante l'installazione vengono creati due file di registrazione. Uno è specifico per XJ1
  e contiene informazioni su azioni di personalizzazione del prodotto.  Questo
  file di registrazione si chiama "xe1instlog.txt" e viene sempre creato nell'indirizzario
  temp dell'utente.

  L'altra registrazione è la registrazione MSI di Microsoft che contiene informazioni sulle
  proprietà, le sequenze e gli eventi MSI.  Per impostazione predefinita, questa registrazione viene denominata
  "xe1instlogmsi.txt" e viene creata nell'indirizzario temp dell'utente.   È possibile modificare questa
  registrazione cambiando setup.ini nell'immagine di installazione.  Cercare la parola chiave [Startup]
  e modificare la seguente voce: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Per impedire la creazione di questa registrazione, eliminare la voce
    - Per modificare l'ubicazione e il nome delle registrazione, modificare il percorso e il nome file
    - Per modificare il contenuto della registrazione, modificare l'opzione /l* con una differente come
      descritto nell'articolo Microsoft's MSDN Windows Installer Command Line Options
      al seguente indirizzo 

      http://msdn.microsoft.com/default.aspx   

  Le informazioni predefinite della riga comandi in setup.ini possono essere sovrascritte
  lanciando setup.exe nella richiesta comandi con le opzioni della riga comandi.



-------------------------------------------------------------------

4.0 Requisiti .NET Provider IBM.Data.DB2.iSeries 

-------------------------------------------------------------------

  - .NET Provider di IBM i Access per Windows (IBM.Data.DB2.iSeries)
    richiede l'installazione di Microsoft .NET Framework Versione 2.0 o successiva sul
    sistema.  La maggior parte dei PC che utilizzano sistemi operativi Microsoft supportati dispongono già di
    .NET Framework installato.  È possibile scaricare .NET Framework dal seguente sito Web di Microsoft: 

    http://www.microsoft.com/net 

  - Per evitare di interrompere le applicazioni .NET scritte nell'interfaccia del provider .NET di Access per Windows 5.3
    o 5.4, è necessario reindirizzare le richieste del tempo di esecuzione per la versione 10.0.0.0 del
    provider .NET alla versione 12.0.0.0.  Consultare
    l'argomento relativo alle modifiche non compatibili da 5.3 e 5.4 in
    IBM DB2 for i .NET Provider Technical Reference per istruzioni su come utilizzare
    un file app.config, un file web.config oppure un file machine.config e per informazioni
    sulla selezione di un compilatore appropriato per il reindirizzamento delle applicazioni esistenti.

    In alternativa, è possibile ricompilare l'applicazione utilizzando un nuovo compilatore per
    la versione 12.0.0.0 del provider .NET incluso nel release IBM i Access per Windows
    7.1.

  - Per informazioni complete e un elenco di modifiche incompatibili, installare la
    funzione Intestazioni, Librerie e Documentazione e visualizzare .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser o Microsoft XML Core Services

-------------------------------------------------------------------

  Quando si utilizzano gli oggetti di automazione ActiveX di Trasferimento dati in IBM i Access per Windows, per trasferire i file nel e dal formato XML
  Microsoft Excel (supportato da Excel 2003 e
  Excel XP), occorre installare ulteriore software sul PC. Questa funzione richiede che Microsoft XML Parser 3.0 o successive, conosciuto
  anche come Microsoft XML Core Services, sia installato sul personal computer. XML Parser è incluso in molti prodotti
  Microsoft.  Per determinare se il supporto XML Parser è installato sul PC, fare riferimento a
  Microsoft KB articolo 278674.  Questo articolo può essere consultato sul sito Web di Microsoft all'indirizzo:

  http://support.microsoft.com/kb/278674

  Se non si trova Microsoft XML Parser 3.0 o una versione successiva, sarà necessario accedere
  al sito Web di Microsoft per istruzioni su come scaricare ed installare XML Parser prima
  di poter utilizzare il supporto di trasferimento dati XML.  Fare riferimento a Microsoft KB articolo 324460
  per informazioni sull'installazione di XML Parser.  Questo articolo può essere consultato all'indirizzo:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informazioni sull'installazione avanzata

-------------------------------------------------------------------

  È possibile utilizzare la maggior parte delle informazioni relative alla modifica
del livello dell'interfaccia utente, all'utilizzo dei parametri della riga comandi,
al controllo di altre funzionalità di installazione e metodi di distribuzione, presenti
nell'argomento "Configurazione del PC" dell'IBM i Information Center per
  IBM i Access per Windows.  Le differenze sono descritte in questa sezione.


6.1 Informazioni sul prodotto su licenza
----------------------------------
  
  5733XJ1 non viene fornito come prodotto su licenza da installare nel sistema operativo IBM i.
  È disponibile solo come supporto PC. È possibile copiarlo in IBM i in una ubicazione disponibile per gli utenti,
  se lo si desidera.
  

6.2 File della lingua nell'immagine di installazione
--------------------------------------------
  
  I file di installazione della lingua non sono più separati in indirizzari MRI29xx differenti
  nell'immagine di installazione. Sono invece presenti file cab separati per ciascuna lingua.  Non
  è possibile rimuovere tali file cab dall'immagine.


6.3 Funzioni di installazione
--------------------

  Alcune funzioni di installazione in IBM i Access per Windows dipendono dall'installazione
di altre funzioni.  Questa limitazione non è valida per questo pacchetto.

  L'installazione delle seguenti funzioni è obbligatoria:
    req (programmi obbligatori)
    langacs, amri2924 (Inglese)

  Tutte le altre funzioni di installazione vengono installate per impostazione predefinita, ma all'utente è consentito modificare l'impostazione.

  Le lingue ora sono funzioni di installazione, proprio come i programmi obbligatori, ODBC, ecc.
Per questo motivo è possibile controllare quali lingue sono installate tramite lo stesso metodo
utilizzato per controllare qualsiasi funzione di installazione.  I nomi delle funzioni di installazione
per le lingue sono amri29xx.  


6.4 Opzioni della riga comandi
------------------------

  Le opzioni predefinite della riga comandi sono specificate nel file setup.ini incluso
  nell'immagine di installazione.  Tali opzioni verranno ignorate se si richiama setup.exe
dalla riga comandi con qualsiasi opzione specificata.  

  Se si utilizza una trasformazione sulla riga comandi, i valori riga comandi in setup.ini
  verranno ignorati poiché la trasformazione è un'opzione.  Sarà necessario includere altre
opzioni sulla riga comandi, come le informazioni di registrazione.

  Per ulteriori informazioni, consultare la sezione 3.7 File di registrazione dell'installazione.


6.5 Proprietà pubbliche
---------------------

  Alcune delle proprietà pubbliche di IBM i Access per Windows sono valide per questo pacchetto.  L'uso
  prevede però alcune differenze rispetto a quello in IBM i Access per Windows, come descritto di seguito:

  CWBINSTALLTYPE   Questa proprietà è utilizzata solo alla prima installazione.  Gli unici valori
                   sono Typical e Custom.  Il valore predefinito è Typical.
                   Esempio:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   La lingua principale predefinita è la locale del PC.  Questa proprietà
                   consente di specificare una lingua principale differente. Il valore da utilizzare è MRI29xx. 
                   Esempio:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   L'uso di questa proprietà è uguale a quello in IBM i Access per Windows.  Consente di
                   aggiornare i file SSL durante un aggiornamento.  Se sul PC di destinazione
                   vengono individuati file di configurazione per SSL, essi verranno aggiornati
                   con i certificati più recenti.  I valori sono Yes e No. Il valore predefinito è Yes.
                   Esempio:  setup /vCWBUPGSSLFILES=NO

  Rimangono applicabili le proprietà comuni di Windows Installer
  elencate nell'argomento dell'Information Center IBM i Access per Windows: ADDLOCAL,
  REMOVE, INSTALLDIR, TARGETDIR.  

  Esiste una limitazione sull'utilizzo della proprietà REBOOT di
  Windows Installer con IBM i Access
  per Windows.  Questa limitazione non è valida per questo pacchetto.
  

6.6 Masterizzazione delle immagini amministrative su CD o DVD
----------------------------------------------

  A causa dei problemi relativi alla modalità con cui il software di masterizzazione di CD e DVD gestisce i nomi dei file lunghi,
      la masterizzazione di un'immagine amministrativa su un CD o DVD non è consigliata. Se vengono riscontrati dei problemi
      durante l'installazione da un CD o un DVD contenente un'immagine amministrativa di IBM i Access per
      Windows, copiare l'immagine in un indirizzario sul disco rigido locale ed eseguire setup.exe dalla
      copia locale.

-------------------------------------------------------------------
7.0 Informazioni sulle normative
-------------------------------------------------------------------

  Lo stesso file di normative viene utilizzato sia per questo pacchetto che per IBM i Access per Windows. Ciò
  significa che alcune di tali normative non sono applicabili se utilizzate per questo pacchetto, poiché
  alcune delle funzioni in IBM i Access per Windows non esistono in questo pacchetto.

-------------------------------------------------------------------

8.0 Comandi
-------------------------------------------------------------------

  I comandi in IBM i Access per Windows che non sono inclusi in questo pacchetto:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[FINE DEL DOCUMENTO]
