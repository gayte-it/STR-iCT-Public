==============================================================================

            5733XJ1 IBM i Access Client Solutions -ohjelmisto
              Windows Application Package 1.1.0 -paketti
    
   (c) Copyright IBM Corporation 1996, 2019.  Kaikki oikeudet pidätetään. 

==============================================================================
    IBM julkaisee tämän asiakirjan tiedot "sellaisenaan" ilman mitään
  nimenomaisesti tai konkludenttisesti myönnettyä takuuta, mukaan
  luettuina taloudellista hyödynnettävyyttä, sopivuutta tiettyyn
  tarkoitukseen ja oikeuksien loukkaamattomuutta koskevat
  konkludenttisesti ilmaistut takuut. Tämän asiakirjan hankinta
    ei anna mitään lisenssiä mihinkään patentteihin tai
    tekijänoikeuksiin. 

===============================================================================

Tämä asiakirja on päivitetty viimeksi 4.11.2019.

------------------------------------------------------------------- 

SISÄLLYSLUETTELO 

-------------------------------------------------------------------  

1.0 Esittely
2.0 Tietolähteiden sijainti
3.0 Asennus
  3.1 Tuetut Windows-käyttöjärjestelmät
  3.2 Asennuksessa huomioon otettavaa
  3.3 Päivitys IBM i Access for Windows -ohjelmistosta
  3.4 Asennuksen ajo
  3.5 Kirjoitinajurin asennuksen jälkeen edellytetyt toimet
  3.6 64-bittisiin järjestelmiin liittyviä asennustietoja
  3.7 Asennuksen lokitiedostot
4.0 IBM.Data.DB2.iSeries .NET Provider -ohjelman asennusvaatimukset
5.0 Microsoft XML Parser- eli Microsoft XML Core Services -palvelu
6.0 Asennuksen lisätiedot
  6.1 Lisensoidun tuotteen tiedot
  6.2 Asennuksen näköistiedoston kielitiedostot
  6.3 Asennettavat ominaisuudet
  6.4 Komentorivin valinnat
  6.5 Julkiset ominaisuudet
  6.6 Hallinnallisten näköistiedostojen polttaminen CD- tai DVD-levylle
7.0 Menettelytiedot
8.0 Pois jätetyt komennot
  


-------------------------------------------------------------------

1.0 Esittely
-------------------------------------------------------------------
  Tämä paketti kuuluu 5733XJ1 IBM i Access Client Solutions -tuotteeseen.

  IBM i Access Client Solutions -ohjelman avulla voit muodostaa yhteyden mihin tahansa tuettuun IBM i -versioon.

  Tämä paketti sisältää toimintoja, jotka ovat käytettävissä vain Windows-käyttöjärjestelmissä.  Paketti perustuu 7.1 IBM i Access for Windows -tuotteeseen, mutta se ei sisällä kaikkia samoja ominaisuuksia.

  Tähän pakettiin kuuluvat seuraavat IBM i Access for Windows -ominaisuudet:
    .NET Data Provider
    ODBC
    OLE DB
    SSL-suojaus ja varmenteiden hallinta
    Programmer's Toolkit -ohjelma header-tiedostoja, kirjastoja ja opasohjelmia varten
    AFP-kirjoitinajuri
    Pakolliset ohjelmat (esimerkiksi seuraavat):
      Sovellusohjelmaliittymät
      Active X
      Suojaus
      Huollettavuus
      Yhteydet
      Kansallisen kielen tuen käyttöönotto
      Muuntotaulukot
      Ominaisuudet
      Menettelyt
      Verkkotulostus
      Komentojen alijoukko (katso osasta 8.0 poisjätettyjen komentojen luettelo)
      Käyttöopas
      Paketin toimintojen käyttöoikeuksien hallinta sovellusten hallinnan avulla.

  Seuraavat IBM i Access for Windows -ominaisuudet eivät sisälly tähän pakettiin. 
  Käyttöympäristöstä riippumaton IBM i Access Client Solution -paketti sisältää korvaavat
  ominaisuudet seuraaville ominaisuuksille:
    5250-pääte-emulointi ja 5150-kirjoitinemulointi
    Tiedonsiirto
    Tiedonsiirron Excel-lisäosa
    Operations Console -ohjauspääte
  
  Seuraavat IBM i Access for Windows -ominaisuudet eivät sisälly tähän pakettiin. 
  IBM Navigator for i sisältää korvaavat ominaisuudet seuraaville ominaisuuksille:
    System i Navigator
    AFP Workbench Viewer.

  Saapuva etäkomento -ominaisuus ei sisälly pakettiin.  Korvaavana ominaisuutena voi käyttää Microsoftin Remote Desktop Services -palvelua.

  Toolbox for Java -ominaisuus ei myöskään sisälly pakettiin.  Lataustiedot ovat saatavana seuraavasta Web-sivustosta:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Muut IBM i Access for Windows -ominaisuudet, jotka eivät sisälly tähän pakettiin, ovat
    SCS-kirjoitinajuri
    Java Programmer's Tools for System i Navigator -lisäosat
    Hakemiston päivitys
    Lotus 123 -tiedostomuodon tuki
    Huoltopaketin tason tarkistus.

  Tämän paketin sisältö toimitetaan myös 7.1 IBM i Access for Windows -ohjelmiston
  yhteydessä, joten käyttöoppaassa, Programmer's Toolkit -ohjelmassa sekä ohjeteksteissä ja sanomissa annettavat ohjeet ja versiot vastaavat usein 7.1 IBM i Access for Windows -ohjelmistoa, mutta ne ovat sovellettavissa myös IBM i Access Client Solutions – Windows Application Package -pakettiin.


-------------------------------------------------------------------

2.0 Tietolähteiden sijainti

-------------------------------------------------------------------

  - IBM i Access Client Solutions -ohjelmiston muutokset, jotka koskevat esimerkiksi tuettuja käyttöjärjestelmiä, päivityksiä, rajoituksia, merkittäviä tunnettuja ongelmia ja uusia tietoja, julkaistaan IBM i Access -tuotteen Web-sivustossa:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Tämän paketin mukana asennettava käyttöopas sisältää tuotteen käyttöä, vihjeitä ja menetelmiä, sanomia sekä vianmääritystä koskevia tietoja.

  - Järjestelmä asentaa OLE DB -palvelun ja .NET Data Provider -ohjelman tekniset viitetiedot Header-tiedostot, kirjastot ja opasohjelmat -ominaisuuden asennuksen yhteydessä.  Tekniset viitetiedot sijaitsevat Programmer's Toolkit -ohjelman kansiossa.

  - IBM i Information Center -sivusto sisältää kokoelman sellaisille IBM i -ammattilaisille tarkoitettuja aiheita, joiden tulee päästä käsiksi teknisiin tietoihin:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Tämän asiakirjan julkaisuhetkellä IBM i Information Center -sivustossa ei ollut IBM i Access Client Solutions -ohjelmistoa käsitteleviä aiheita.  Suuri osa IBM i Access for Windows -ohjelmistoa koskevista tiedoista pätee kuitenkin myös tähän IBM i Access Client Solutions -ohjelmistoon. Tällaisia tietoja ovat esimerkiksi asennus-, hallinta- ja ohjelmointiaiheet:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks -sivusto sisältää artikkeleita, opetusohjelmia ja teknisiä resursseja IBM i -käyttäjille:

    https://www.ibm.com/developerworks/ibmi

  - IBM i -Web-sivusto sisältää viimeisimmät IBM i -uutiset, tuotetietoja, viitekirjaston, kurssiohjelmia ja paljon muita tietoja:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Asennustiedot
-------------------------------------------------------------------



3.1 Tuetut Windows-käyttöjärjestelmät
---------------------------------------

  Tämä paketti voidaan asentaa seuraaviin Microsoft Windows -käyttöjärjestelmiin:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 ja Windows Server 2008 R2
         Standard Enterprise (32-bittinen ja 64-bittinen)
   - Windows 7
         Professional, Enterprise ja Ultimate (32-bittinen ja 64-bittinen)

   Voimassa ovat seuraavat
rajoitukset:
 
     a) Home-versiot eivät ole tuettuja.
     b) Windows-päivityspakettien (Service Pack) versioiden on oltava Microsoftin
        tukemia.
     c) Käyttötukea on saatavana vain niin kauan kuin Microsoft tarjoaa käyttötukea.
     d) Asennus Itanium-laitteistoon ei ole tuettua.
     e) Käytä Microsoft Windows -käyttöjärjestelmän laitteisto- ja muistisuosituksia. Lisää 256 Mt muistia IBM i Access Client Solution -toimintoja varten.
     f) Tuotetta ei voi asentaa, jos Windows-käyttöjärjestelmä päivitetään
        toiseen versioon.  Toimi seuraavasti:
          1.  Tallenna kokoonpanotiedot.
          2.  Poista tuotteen asennus.
          3.  Päivitä Windows-käyttöjärjestelmä.
          4.  Asenna tuote.
          5.  Palauta kokoonpanotiedot.


3.2 Asennuksessa huomioon otettavaa
--------------------------------------------------

  - Asennuksen ajaminen edellyttää pääkäyttäjän oikeuksia ja valtuuksia.
  
  - Vain konekohtaiset asennukset ovat tuettuja.  Käyttäjäkohtaiset asennukset
    eivät ole tuettuja.

  - Windows Installer 4.5 -ohjelma on pakollinen asennuksessa.  Järjestelmä asentaa
    tämän Microsoft-ohjelmistokomponentin asennuksen yhteydessä, jos sitä ei ole
    asennettuna järjestelmässä.  Voit asentaa komponentin ennen varsinaista asennusta
    lataamalla sen Microsoftin Web-sivustosta:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Päivitys IBM i Access for Windows -ohjelmistosta
-------------------------------------------

  -  Päivitys IBM i Access for Windows -ohjelmistosta ei ole
     tuettua.  IBM i Access for Windows on poistettava, ennen
     kuin tämä paketti asennetaan.  

  -  Lisätietoja ominaisuuksista, jotka eivät sisälly pakettiin, on
     osassa 1.0.  Jos haluat edelleen käyttää IBM i Access for Windows
     -ohjelmiston ominaisuuksia, joita tämä paketti ei sisällä, älä
     asenna tätä pakettia, vaan jatka IBM i Access for Windows
     -ohjelmiston viimeisimmän päivityspaketin (7.1) käyttöä.

  -  Jos IBM i Access for Windows -ohjelmiston asennus poistetaan, aiemmin määritetty
     järjestelmäkokoonpano poistetaan.  Mikäli haluat säilyttää aiemmin määritetyn
     kokoonpanon, sinun on tallennettava kokoonpano ennen
     IBM i Access for Windows -ohjelmiston asennuksen poistoa ja palautettava kokoonpano IBM i
     Access Client Solutions Windows Application Package -paketin asennuksen jälkeen.

     Seuraavassa esitellään kokoonpanon tallennuksen ja palautuksen yksityiskohtaiset vaiheet:
     1.  Varmistuskopioi IBM i Access for Windows -kokoonpano
         CWBBACK-komennon avulla.
             cwbback <tiedoston_nimi.rs> /u
         Esimerkki:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Esimerkissä oletetaan, että kansio C:\Users\IBM_ADMIN\Backup on jo järjestelmässä.

         Edellä mainittu komento luo kyseiseen kansioon kaksi tiedostoa:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Varmista, että nämä tiedostot on luotu, ennen kuin siirryt seuraavaan vaiheeseen.

         HUOMAUTUS:
         Jos tiedostoja ei vielä ole luotu, kokoonpanoa ei ole tallennettu.  Yritä antaa komento pääkäyttäjänä.
         Yksi tapa tehdä se on antaa komentokehote seuraavasti: Valitse vaihtoehdot: Käynnistä -> Kaikki ohjelmat -> Apuohjelmat -> Komentokehote
         Mutta sen sijaan, että napsauttaisit komentokehotetta hiiren ykköspainikkeella, napsauta sitä kakkospainikkeella ja valitse vaihtoehto Suorita järjestelmänvalvojana.
         Aja edellä oleva CWBBACK-komento tästä komentokehotteesta.
         Varmista, että edellä mainitut kaksi tiedostoa on luotu, ennen kuin siirryt seuraavaan vaiheeseen.

     2.  Poista IBM i Access for Windows -ohjelmiston asennus.
     3.  Käynnistä tietokone uudelleen.
     4.  Asenna IBM i Access Client Solutions -ohjelmiston Windows Application Package -paketti.
     5.  Käynnistä tietokone uudelleen.
     6.  Palauta CWBBACK-komennolla tallennettu kokoonpano
         antamalla CWBREST-komento.
             cwbrest <tiedoston_nimi.rs> /c
         Esimerkki:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Samoin kuin vaiheen 1 HUOMAUTUS-kohdassa edellytetään, myös CWBREST-komento on ajettava Suorita järjestelmänvalvojana -kehotteesta.

  -  Voit kahdella tavalla tarkistaa Windows-kokoonpanon, ennen edellä olevia
     vaiheita ja niiden jälkeen:
     1. Tarkista Windows-rekisteri.  Järjestelmäkokoonpanot ovat tallennettuina kansiossa:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\Omat yhteydet

	Voit tarkastella Windows-rekisterin sisältöä kyseisessä sijainnissa antamalla tämän komennon:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\Omat yhteydet"
        
        Jos ympäristösi nimi on jokin muu kuin oletusnimi Omat yhteydet,
        tee tarvittava muutos edellä olevaan polkuun.

     2. Jos käytössäsi on käyttöympäristöstä riippumaton IBM i Access Client Solutions -ohjelmiston versio samassa tietokoneessa,
        voit valita graafisesta pääkäyttöliittymästä vaihtoehdot: Tiedosto -> Kopioi yhteydet
        Oikealle puolelle tulee näkyviin IBM i Access (Windows).  Tätä kokoonpanoa käytetään sekä IBM i Access for Windows -ohjelmistolle että IBM i Access Client Solutions -ohjelmiston Windows Application Package -paketille.


3.4 Asennuksen ajo
-----------------------

  - Aloita asennus ajamalla asennuksen näköistiedoston setup.exe-tiedosto.  (Komentoa cwblaunch.exe ei toimiteta tämän tuotteen mukana.)
   
      HUOMAUTUS: Microsoft Installer (MSI) -tiedostojen suora kutsuminen
               ei ole suositeltavaa, koska setup.exe noutaa käytettävät komentorivin valinnat ja päivittää tarvittaessa Windows Installer -ohjelman version käyttämällä setup.ini-tiedostoa.
    
  - On suositeltavaa käyttää oletuskohdekansiota.  Jos kuitenkin muutat kansiota, toimi seuraavasti:
     
     a) Älä valitse minkään aseman päähakemistoa.
     b) Älä valitse hakemistoa, joka sisältää muita kuin tähän tuotteeseen
        liittyviä tiedostoja.
     c) Älä valitse verkkoasemaa.  Asennus verkkoasemaan ei ole tuettu.


3.5 Kirjoitinajurin asennuksen jälkeen edellytetyt toimet
---------------------------------------------------

  Jos asennat kirjoitinajurin, sinun on tehtävä joitakin toimia ennen ajurin
  käyttöä.  Kirjoitinajurin automaattinen lisäys tai päivitys asennuksen yhteydessä ei onnistu, koska Microsoft ei ole allekirjoittanut kirjoitinajuria digitaalisesti.  

  Järjestelmä kopioi kirjoittimen ajuritiedostot asennuksen yhteydessä valitussa
  kohdepolussa sijaitsevaan CWBAFP-alihakemistoon.  Jos asennuksessa on käytetty
  oletusarvon mukaista kohdepolkua, koko polku on seuraava:

  c:\Program Files\IBM\Client Access\CWBAFP 

  Lisää tai päivitä kirjoitinajuri noudattamalla Microsoftin ohjetekstiä.
  Määritä polku kehotettaessa osoittamaan CWBAFP-hakemistoon. 

  Jos teet asennusta tietokoneeseen, jossa IBM i Access for Windows -tuote on
  päivitetty useita laitoksia uudempaan laitokseen, kirjoitinajurin määrityksen
  aikana näkyviin saattaa tulla vanhentuneita tietoja.  Voit poistaa vanhentuneet tiedot .inf-tiedostoista tekemällä seuraavat
  toimet asennuksen viimeistelyn jälkeen:

    a) Avaa komentorivi-ikkuna.
    b) Siirry asennushakemistoon. Oletusasennushakemisto
        on c:\Program Files\IBM\Client Access.
    c) Kirjoita komentoriville "cwbrminf" ja paina Enter-näppäintä. 


3.6 64-bittisiin järjestelmiin liittyviä asennustietoja
-------------------------------------------------------

  Kun asennus tehdään tuettuun 64-bittiseen Windows-käyttöjärjestelmään:
  
  -  Järjestelmä asentaa ODBC-, OLE DB-, ActiveX- ja SSL (Secure Sockets Layer) -toiminnoista sekä 32-bittisen että 64-bittisen version.  

  -  IBM i Access for Windows -ohjelmiston .NET Provider -ohjelman voi ajaa sekä
     32- että 64-bittisistä sovelluksista ohjelmaa kutsuvan sovelluksen mukaan.

  -  Järjestelmä asentaa vain yhden AFP-kirjoitinajurin version.  Järjestelmä asentaa 64-bittisen version 64-bittisiin järjestelmiin ja 32-bittisen version 32-bittisiin järjestelmiin.


3.7 Asennuksen lokitiedostot
----------------------------

  Järjestelmä luo kaksi lokitiedostoa asennuksen yhteydessä. Toinen lokeista on XJ1-loki, joka sisältää tuotteen mukautetut toimintotiedot.  Tämän lokitiedoston nimi on xe1instlog.txt, ja järjestelmä luo sen
aina käyttäjän tilapäishakemistoon.

  Toinen loki on Microsoftin MSI-loki, joka sisältää tietoja MSI-tapahtumista,
  -sarjoista ja -ominaisuuksista.  Tämän lokin oletusnimi on
xe1instlogmsi.txt, ja asennusohjelma luo sen
käyttäjän tilapäishakemistoon.   Voit muuttaa tätä lokia
  muokkaamalla asennuksen näköistiedoston setup.ini-tiedostoa.  Siirry avainsanaan
  [Startup]. Etsi sitten seuraava merkintä ja muokkaa sitä: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Jos haluat estää lokin luonnin, poista merkintä.
    - Jos haluat muuttaa lokin sijainnin ja nimen, muuta polun ja tiedoston nimeä.
    - Jos haluat muuttaa lokin sisältöä, muuta valitsimen /l* tilalle toinen
      valitsin. Tietoja valitsimista on Microsoftin ohjeessa
      MSDN Windows Installer Command Line Options
      osoitteessa   

      http://msdn.microsoft.com/default.aspx.   

  Tiedostossa setup.ini määritetyt oletusarvojen mukaiset komentorivitiedot voidaan ohittaa aloittamalla setup.exe kehotteessa käyttämällä haluttuja komentorivin valintoja.



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider -ohjelman asennusvaatimukset 

-------------------------------------------------------------------

  - IBM i Access for Windows -ohjelmiston .NET Data Provider -ohjelma
    (IBM.Data.DB2.iSeries) edellyttää, että järjestelmässä on asennettuna
    Microsoft .NET Framework -kehitysympäristön versio 2.0 tai sitä uudempi
    versio.  Useimmissa tietokoneissa, joissa on käytössä Microsoft-käyttöjärjestelmä, on pakollinen .NET Framework -ympäristö valmiiksi asennettuna.  Sen voi noutaa Microsoftin Web-sivustosta osoitteessa 

    http://www.microsoft.com/net. 

  - Jotta vältät Access for Windows -version 5.3 tai 5.4 .NET-palvelun
    liittymää käyttävien .NET-sovellusten käyttökatkokset, ajonaikaiset
    pyynnöt .NET Provider -ohjelman versioon 10.0.0.0 on ohjattava ohjelman
    versioon 12.0.0.0.  Tietoja tiedoston app.config, web.config tai
    machine.config käytöstä sekä aiemmin luotujen sovellusten edelleenohjaukseen
    käytettävän kääntäjän valinnasta on julkaisun
    IBM DB2 for i .NET Provider Technical Reference jaksossa
    Incompatible changes from 5.3 and 5.4.

    Toinen keino on kääntää sovellus uudelleen uudemmalla kääntäjällä
    siten, että kohteena on IBM i Access for Windows -ohjelmiston
    laitokseen 7.1 sisältyvä .NET Provider -ohjelman versio 12.0.0.0.

  - Saat täydelliset tiedot sekä luettelon yhteensopimattomista muutoksista
    asentamalla Header-tiedostot, kirjastot ja
    opasohjelmat -ominaisuuden ja avaamalla sitten julkaisun
    .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser- eli Microsoft XML Core Service -palvelu

-------------------------------------------------------------------

  Jos IBM i Access for Windows Data Transfer ActiveX -automatisointiobjekteja käytetään tiedostojen siirtoon Microsoft Excel XML-muotoon ja -muodosta (tämä ominaisuus on tuettu Excel 2003- ja Excel XP -versioissa), tietokoneeseen on asennettava lisäohjelmisto. Tämä ominaisuus edellyttää, että tietokoneeseen on asennettu Microsoft XML Parser 3.0 tai sitä uudempi versio. Ohjelma tunnetaan myös
  nimellä Microsoft XML Core Services. XML Parser -ohjelma sisältyy moniin
  Microsoft-tuotteisiin.  Voit Microsoft Knowledge Base -tietokannan artikkelin
  278674 avulla selvittää, onko XML Parser -tuki asennettu PC:hen.  Tämä artikkeli
  on Microsoftin Web-sivustossa osoitteessa

  http://support.microsoft.com/kb/278674.

  Jos Microsoft XML Parser -ohjelman versiota 3.0 tai sitä uudempaa versiota
  ei löydy, voit käyttää tiedonsiirron XML-tukea vasta, kun olet noutanut
  ja asentanut XML Parser -ohjelman Microsoftin Web-sivustosta kyseisen sivuston
  ohjeiden mukaan.  Lisätietoja XML Parser -ohjelman asennuksesta on Microsoft
  Knowledge Base -tietokannan artikkelissa 324460.  Tämä artikkeli on osoitteessa

  http://support.microsoft.com/kb/324460.


-------------------------------------------------------------------

6.0 Asennuksen lisätiedot

-------------------------------------------------------------------

  Useimmat käyttöliittymän tason muuttamista, komentorivin parametrien käyttöä, muiden asennuksen toimintojen ohjausta ja käyttöönottomenetelmiä koskevat tiedot ovat saatavana IBM i Access for Windows -ohjelman IBM i Information Center -sivuston aiheessa Setting up the PC.  Tässä osassa kuvataan kyseisten toimintojen erot.


6.1 Lisensoidun tuotteen tiedot
----------------------------------
  
  5733XJ1-ohjelma ei sisälly pakettiin lisensoituna tuotteena, joka asennetaan IBM i -käyttöjärjestelmään.
  Se on saatavana vain PC-tallennusvälineenä. Voit halutessasi kopioida ohjelman käyttäjien käytettävissä olevaan sijaintiin IBM i -järjestelmässä.
  

6.2 Asennuksen näköistiedoston kielitiedostot
--------------------------------------------
  
  Kieliversioiden asennustiedostoja ei ole enää jaettu erillisiin MRI29xx-hakemistoihin
  asennuksen näköistiedostossa. Sen sijasta kullekin kieliversiolle on oma CAB-tiedostonsa.  CAB-tiedostoja ei voi poistaa näköistiedostosta.


6.3 Asennettavat ominaisuudet
--------------------

  Osa IBM i Access for Windows -ohjelman asennettavista ominaisuuksista on riippuvaisia muista asennettavista ominaisuuksista.  Rajoitus ei koske tätä pakettia.

  Seuraavat asennettavat ominaisuudet ovat pakollisia:
    req (pakolliset ohjelmat)
    langacs, amri2924 (englannin kielitiedostot).

  Järjestelmä asentaa kaikki muut asennettavat ominaisuudet oletusarvon mukaan, mutta näitä asetuksia voi muuttaa.

  Kielitiedostot ovat nyt asennettavia ominaisuuksia aivan kuten esimerkiksi pakolliset ohjelmat ja ODBC-tietokanta. Koska kielet ovat asennettavia ominaisuuksia, voit määrittää asennettavat kielet samalla tavalla kuin muutkin asennettavat ominaisuudet.  Kielitiedostojen asennettavien ominaisuuksien nimien muoto on amri29xx.  


6.4 Komentorivin valinnat
------------------------

  Oletusarvon mukaiset komentorivin valinnat määritetään asennuksen näköistiedoston sisältämässä setup.ini-tiedostossa.  Järjestelmä ohittaa kyseiset valinnat, jos setup.exe kutsutaan komentoriviltä niin, että komentoon määritetään valintoja.  

  Jos komentorivillä käytetään muunnosta, järjestelmä ohittaa setup.ini-tiedoston komentorivin arvot, koska muunnos itsessään on valinta.  Tällöin komentorivillä on määritettävä lisävalintoja, kuten sisäänkirjaustiedot.

  Lisätietoja on osassa 3.7 Asennuksen lokitiedostot.


6.5 Julkiset ominaisuudet
---------------------

  Osa IBM i Access for Windows -ohjelman julkisista ominaisuuksista sisältyy tähän pakettiin.  Ominaisuuksien käyttö eroaa IBM i Access for Windows -ohjelmasta seuraavasti:

  CWBINSTALLTYPE   Tämä ominaisuus on käytössä vain ensimmäisellä asennuskerralla.  Ainoat arvot ovat Typical (normaali) ja Custom (mukautettu).  Oletusarvo on Typical.
                   Esimerkki:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Oletusarvon mukainen ensisijainen kieli on tietokoneen paikallistunnus.  Tämän ominaisuuden avulla voidaan määrittää jokin toinen ensisijainen kieli. Käytettävä arvo on muodossa MRI29xx. 
                   Esimerkki:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Tätä ominaisuutta käytetään samalla tavalla kuin IBM i Access for Windows -ohjelmassa.  Ominaisuuden avulla voidaan päivittää SSL-tiedostot päivityksen yhteydessä.  Jos SSL-kokoonpanotiedostot sijaitsevat kohdetietokoneessa, järjestelmä päivittää niihin uusimmat varmenteet.  Mahdollisia arvoja ovat Yes (kyllä) ja No (ei).  Oletusarvo on Yes.
                   Esimerkki:  setup /vCWBUPGSSLFILES=NO

  Seuraavat IBM i Access for Windows -ohjelman Information Center -sivustossa kuvatut yleiset Windows Installer -ominaisuudet ovat käytössä: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Windows Installer -ominaisuuden REBOOT käyttöä on rajoitettu IBM i Access for Windows -ohjelmassa.  Rajoitus ei koske tätä pakettia.
  

6.6 Hallinnallisten näköistiedostojen polttaminen CD- tai DVD-levylle
----------------------------------------------

  Koska joissakin CD- ja DVD-poltto-ohjelmissa on ilmennyt ongelmia
      pitkiä tiedoston nimiä käsiteltäessä, hallinnallisen
      näköistiedoston poltto CD- tai DVD-tietolevyyn ei ole suositeltavaa. Jos IBM i Access For Windows -ohjelmiston hallinnallista näköistiedostoa
      CD- tai DVD-tietolevystä asennettaessa ilmenee ongelmia, kopioi
      näköistiedosto paikallisen kiintolevyaseman hakemistoon ja aja setup.exe
      paikallisesta kopiosta.

-------------------------------------------------------------------
7.0 Menettelytiedot
-------------------------------------------------------------------

  Samaa menettelytiedostoa käytetään sekä tämän paketin että IBM i Access for Windows -ohjelman yhteydessä. Tämä merkitsee sitä, että osa kyseisistä käytännöistä ei ole käytössä tässä paketissa käytettäessä, koska paketti ei sisällä kaikkia IBM i Access for Windows -toimintoja.

-------------------------------------------------------------------

8.0 Komennot
-------------------------------------------------------------------

  Seuraavat IBM i Access for Windows -komennot eivät sisälly tähän pakettiin:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe.
    
[LOPPU]
